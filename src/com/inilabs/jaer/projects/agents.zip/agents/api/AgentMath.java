/*
 * Copyright (C) 2025 rjd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301  USA
 */
package com.inilabs.jaer.projects.agents.api;

/**
 *
 * @author rjd
 */

import com.inilabs.jaer.projects.space3d.Space3D;
import com.inilabs.jaer.projects.agents.api.AgentTypes.AzElDist;

public final class AgentMath {
    private AgentMath(){}

    public static AzElDist azElDistFromDVX(Space3D.Vec3 ref, Space3D.Vec3 pos){
        Space3D.Vec3 d = pos.sub(ref);
        double az = Math.toDegrees(Math.atan2(d.x, d.z));
        double el = Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z)));
        return new AzElDist(az, el, d.norm());
    }
}
