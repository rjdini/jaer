/*
 * Copyright (C) 2025 rjd.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301  USA
 */
package com.inilabs.jaer.projects.agents.core;

/**
 *
 * @author rjd
 */

// com.inilabs.jaer.projects.agents.core.AbstractAgent
import java.util.Objects;
import com.inilabs.jaer.projects.agents.api.*;
import com.inilabs.jaer.projects.space3d.Space3D;

public abstract class AbstractAgent implements Agent, HasPose3D, HasLLA {
    protected final String key;
    public final AgentTypes.ObjectType type;
    protected Space3D.Vec3 posDVX = new Space3D.Vec3(0,0,0);
    protected double yawDeg=0, pitchDeg=0, rollDeg=0;
    protected double latDeg=Double.NaN, lonDeg=Double.NaN, altM=Double.NaN;
    protected volatile boolean enabled = true;
    
    protected AbstractAgent(String key, AgentTypes.ObjectType type){
        this.key = Objects.requireNonNull(key);
        this.type = Objects.requireNonNull(type);
    }
   
    public boolean isActive() { return enabled; }
    public void setActive(boolean on) { enabled = on; }

    @Override public String getKey(){ return key; }
    @Override public AgentTypes.ObjectType getType(){ return type; }

    @Override public Space3D.Vec3 getPosition3D(){ return posDVX; }
    @Override public void setPosition3D(Space3D.Vec3 p){ posDVX = Objects.requireNonNull(p); }

    @Override public double[] getYawPitchRollDeg(){ return new double[]{yawDeg,pitchDeg,rollDeg}; }
    @Override public void setYawPitchRollDeg(double yaw,double pitch,double roll){
        this.yawDeg=yaw; this.pitchDeg=pitch; this.rollDeg=roll;
    }

    @Override public double[] getLLA(){ return new double[]{latDeg,lonDeg,altM}; }
    @Override public void setLLA(double lat,double lon,double alt){ this.latDeg=lat; this.lonDeg=lon; this.altM=alt; }
}
